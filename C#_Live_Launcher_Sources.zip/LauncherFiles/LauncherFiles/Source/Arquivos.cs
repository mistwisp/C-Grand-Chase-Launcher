﻿namespace LauncherFiles.Source{
    public class Arquivos{
        public int FileID { get; set; }
        public string FileHash { get; set; }
        public string FilePath { get; set; }
    }
}